<?php

namespace Illuminate\Cache\Events;

class KeyForgetFailed extends CacheEvent
{
    //
}
